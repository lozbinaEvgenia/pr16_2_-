﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace пр_16_лозбина
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] array = { 5.1, 1.3, 9.2, 2, 3, 5.1, 3 };
            ArrayList frequencies = new ArrayList();

            foreach (double num in array)
            {
                int count = 0;
                foreach (double element in array)
                {
                    if (element == num)
                    {
                        count++;
                    }
                }
                if (!frequencies.Contains(num))
                {
                    frequencies.Add(num);
                    frequencies.Add(count);
                }
            }

            Console.WriteLine("Число Номер Частота");
            Console.WriteLine("---------------------");
            for (int i = 0; i < frequencies.Count; i += 2)
            {
                Console.WriteLine($"{frequencies[i]} - {frequencies[i + 1]}");
            }

            Console.WriteLine("\nЧисло Частота(старого массива)");
            Console.WriteLine("--------------------------------");
            foreach (double num in array)
            {
                int count = 0;
                foreach (double element in array)
                {
                    if (element == num)
                    {
                        count++;
                    }
                }
                Console.WriteLine($"{num} - {count}");
            }
        }
    }
    
}
